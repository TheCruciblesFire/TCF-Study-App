# TCF HTML Preview Testing

## Status
This folder was prepared locally. It has NOT been uploaded to Google Drive.
Target Drive folder: https://drive.google.com/drive/folders/1s7S1IiMEtl2BQSyNF9Y60HCTgOvt0VYk

## Folder guide
- 01-ZIP-Releases: Keep each original ZIP in its own version folder.
- 02-Extracted-HTML: Keep a ready-to-open copy of index.html for each version.
- 03-Brand-Assets: Approved flame and branding notes. Add the original full-logo PNG/SVG here when available.
- 04-Screenshots: Desktop and mobile visual references by version.
- 05-Test-Notes: Test checklist, observations, and issues.
- 99-Archive: Move superseded versions here; preserve originals.

## Test the preview
Google Drive stores and shares the files; its file preview does not host the interactive HTML app.
Download a release ZIP, extract it, then open its index.html in Chrome, Edge, Safari, or Firefox.
Alternatively, download the index.html under 02-Extracted-HTML and open that file locally.
All styles, fonts, flame artwork, and prepared example studies are embedded in the HTML.
No server, API key, or internet connection is needed for the three demo studies.
External Blue Letter Bible links use the internet only when clicked.

## Naming future releases
Use folders such as v0.2-branded, and include the same version in ZIP names and test notes.
Never place API keys, .env files, visitor conversation databases, or personal information here.
