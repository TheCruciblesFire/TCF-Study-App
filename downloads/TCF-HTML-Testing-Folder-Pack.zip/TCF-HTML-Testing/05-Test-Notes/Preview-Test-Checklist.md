# Branded preview test checklist

Version: v0.1-branded
Browser / version: ____________________
Device / viewport: ____________________
Tester / date: ________________________

- [ ] Black background, white text, restrained Classic Gold (#ABA346).
- [ ] Supplied flame appears and tagline reads Learn. Teach. Repeat.
- [ ] Fonts, images, and styles work while offline.
- [ ] John 15:1–8 example opens and shows Scripture sources.
- [ ] Psalm 23 and What is grace? examples open.
- [ ] Source buttons expand the relevant passage.
- [ ] Follow-up returns the selected prepared study with demo labeling.
- [ ] New study clears the conversation.
- [ ] Chat input remains visible on mobile; study content scrolls.
- [ ] Privacy dialog opens and closes.
- [ ] Demo clearly says it is not live AI.
- [ ] No API key is requested or exposed.

## Automated validation already performed
The bundled HTML passed browser checks for styling, artwork, examples, sources,
follow-up, reset, mobile layout, privacy, and zero HTTP requests. This does not
verify Google Drive preview behavior or live AI/Bible API credentials.

## Issues found
| Screen or action | Expected | Observed | Screenshot | Status |
| --- | --- | --- | --- | --- |
| | | | | |
